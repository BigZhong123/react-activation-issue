import React from "react"

const Home = () => {

  return (
    <div>
      <input type="text" />
    </div>
  );
}

export default Home