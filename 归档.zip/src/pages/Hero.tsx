import React from 'react';

export const Hero = () => {

  return (
    <div>
      <input type="text" />
    </div>
  );
};

export default Hero